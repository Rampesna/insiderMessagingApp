<?php

namespace App\Core;

/**
 * @OA\Info(
 *     title="Insider Messaging API",
 *     version="1.0.0"
 * )
 */
abstract class Controller
{
    //
}
